package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.PostMapping;  
import org.springframework.web.bind.annotation.PutMapping;  
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;  
import com.example.demo.model.Address;
import com.example.demo.repository.AddressRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.response.NotFoundException;
import com.example.demo.services.AddressService;




//@CrossOrigin(origins = "http://localhost:4200")
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping("/api")
@RestController  
public class AddressController   
{  
 
@Autowired  
AddressService AddressService;  
@Autowired
private UserRepository userRepository;
@Autowired
private AddressRepository addressRepository;
@GetMapping("{userId}/address")  
public List<Address> getContactByUserId(@PathVariable Long userId) {
	
    if(!userRepository.existsById(userId)) {
        throw new NotFoundException("User not found!");
    }
	
	return addressRepository.findByUserId(userId);
}
//For admin get all contacts//
@GetMapping("/address")  
private List<Address> getAllAddress()   
{  
return AddressService.getAllAddress();  
}   
//For admin to edit all contacts
@PutMapping("/address/{addressId}")  
private Address updateAddress(@PathVariable Long addressId,
		@Valid @RequestBody Address addressUpdated)   
{  

return addressRepository.findById(addressId)
        .map(address -> {
            address.setFullName(addressUpdated.getFullName());
            address.setAddress(addressUpdated.getAddress());
            address.setEmail(addressUpdated.getEmail());
            address.setPhone(addressUpdated.getPhone());
            return addressRepository.save(address);
        }).orElseThrow(() -> new NotFoundException("Address not found!"));
}  
//For admin to delete contact of all
@DeleteMapping("/address/{id}")  
private void deleteAddress(@PathVariable("id") long id)   
{  
AddressService.delete(id);  
}  

//For user to delete users contact
@DeleteMapping("{userId}/address/{addressId}")  
public String deleteAddress(@PathVariable Long userId,
		   @PathVariable Long addressId) {

if(!userRepository.existsById(userId)) {
throw new NotFoundException("User not found!");
}

return addressRepository.findById(addressId)
        .map(address -> {
            addressRepository.delete(address);
            return "Deleted Successfully!";
        }).orElseThrow(() -> new NotFoundException("Contact not found!"));
}

@PostMapping("{userId}/address")  
public Address addAddress(@PathVariable Long userId,
        @Valid @RequestBody Address address) {
return userRepository.findById(userId)
.map(user -> {
address.setUser(user);
return addressRepository.save(address);
}).orElseThrow(() -> new NotFoundException("User not found!"));
}
  
@PutMapping("{userId}/address/{addressId}")  
public Address updateAddress(@PathVariable Long userId,
		@PathVariable Long addressId,
		@Valid @RequestBody Address addressUpdated){
	
	if(!userRepository.existsById(userId)) {
		throw new NotFoundException("User not found!");
	}
	
    return addressRepository.findById(addressId)
            .map(address -> {
                address.setFullName(addressUpdated.getFullName());
                address.setAddress(addressUpdated.getAddress());
                address.setEmail(addressUpdated.getEmail());
                address.setPhone(addressUpdated.getPhone());
                return addressRepository.save(address);
            }).orElseThrow(() -> new NotFoundException("Address not found!"));
}
}  
