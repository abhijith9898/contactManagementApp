package com.example.demo.services;

import java.util.ArrayList;  
import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Service;

import com.example.demo.repository.AddressRepository;
import com.example.demo.model.Address;  

//defining the business logic  
@Service  
public class AddressService   
{  
@Autowired  
AddressRepository addressRepository;  
//getting all books record by using the method findaAll() of CrudRepository  
public List<Address> getAllAddress()   
{  
List<Address> address = new ArrayList<Address>();  
addressRepository.findAll().forEach(address1 -> address.add(address1));  
return address;  
}  
//getting a specific record by using the method findById() of CrudRepository  
public Address getAddressById(long id)   
{  
return addressRepository.findById(id).get();  
}  
//saving a specific record by using the method save() of CrudRepository  
public void saveOrUpdate(Address address)   
{  
addressRepository.save(address);  
}  
//deleting a specific record by using the method deleteById() of CrudRepository  
public void delete(long id)   
{  
addressRepository.deleteById(id);  
}  
//updating a record  
public void update(Address address, long id)   
{  
addressRepository.save(address);  
}  
}