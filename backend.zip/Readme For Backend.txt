For Backend.zip

1. First create a database with the name contact 
create database contact;
(change db password in the code according to system requirement)

2. Unzip the backend.zip file and run it 

3. insert these rows for the admin credentials

========================================================================
INSERT INTO roles(name) VALUES('ROLE_USER');

INSERT INTO roles(name) VALUES('ROLE_ADMIN');

INSERT INTO users(username, password) VALUES('admin', '$2a$10$bq6nHSRvu/2T/X.WYn.eBekzM99ul7WIzZjEH1fSypRE6aAmkpUx6');

INSERT INTO user_roles('user_id','role_id') VALUES('1','2');
===========================================================================

4. Run the front end code and you are all set to go.